/*
 * This file must define the following functions:
 *
 * 1) bool predictTimeOfDayOnNextPlanet(std::uint64_t nextPlanetID);
 *
 * 2) void observeAndRecordTimeofdayOnNextPlanet(std::uint64_t nextPlanetID, bool timeOfDayOnNextPlanet);
 *
 */

//Sample implementation

#include "PredictionAlgorithm.hpp"
#include <unistd.h>

bool predictTimeOfDayOnNextPlanet(std::uint64_t nextPlanetID) {
  // model solution overhead
  usleep(5); 
  // predict all as night
  return false;
}

void observeAndRecordTimeofdayOnNextPlanet(std::uint64_t nextPlanetID, bool timeOfDayOnNextPlanet) {
  //do nothing
}
